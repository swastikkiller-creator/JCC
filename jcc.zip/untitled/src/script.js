// Upload note

async function uploadNote() {

  const subject = document.getElementById("subjectSelect").value;

  const chapter = document.getElementById("chapterInput").value;

  const file = document.getElementById("noteFile").files[0];

  if (!chapter || !file) return alert("Fill all fields");

  const formData = new FormData();

  formData.append("subject", subject);

  formData.append("chapter", chapter);

  formData.append("fileName", file.name);

  const res = await fetch("/.netlify/functions/addNote", {

    method: "POST",

    body: JSON.stringify({ subject, chapter, fileName: file.name }),

  });

  const data = await res.json();

  const list = document.getElementById("notesList");

  const li = document.createElement("li");

  li.textContent = `${data.subject} - ${data.chapter} (File: ${data.fileName})`;

  list.prepend(li);

  alert("Note uploaded (demo: only metadata saved)");

}

// Ask doubt

async function askDoubt() {

  const subject = document.getElementById("doubtSubject").value;

  const chapter = document.getElementById("doubtChapter").value;

  const text = document.getElementById("doubtText").value;

  if (!chapter || !text) return alert("Fill all fields");

  const res = await fetch("/.netlify/functions/addDoubt", {

    method: "POST",

    body: JSON.stringify({ subject, chapter, text }),

  });

  const data = await res.json();

  const list = document.getElementById("doubtsList");

  const li = document.createElement("li");

  li.textContent = `${data.subject} - ${data.chapter}: ${data.text}`;

  list.prepend(li);

  alert("Doubt submitted. Teacher reminder triggered!");

}

// Create quiz

async function createQuiz() {

  const title = document.getElementById("quizTitle").value;

  const q = document.getElementById("quizQ").value;

  const a = document.getElementById("quizA").value;

  if (!title || !q || !a) return alert("Fill all fields");

  const res = await fetch("/.netlify/functions/addQuiz", {

    method: "POST",

    body: JSON.stringify({ title, question: q, answer: a }),

  });

  const data = await res.json();

  const list = document.getElementById("quizList");

  const li = document.createElement("li");

  li.textContent = `${data.title} → ${data.question} (Ans: ${data.answer})`;

  list.prepend(li);

  alert("Quiz created!");

}